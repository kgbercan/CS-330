package edu.simmons.bercan.paceguide;

import java.util.*;

/**
 * Created by bercan on 4/22/2016.
 */
public class PaceTable {

    ////// percentages \\\\\\
    // 500 time : goal \\
    HashMap<String,String> ninetyfive = new HashMap<String,String>();
    HashMap<String,String> ninety = new HashMap<String,String>();
    HashMap<String,String> eightyfive = new HashMap<String,String>();
    HashMap<String,String> eighty = new HashMap<String,String>();
    HashMap<String,String> seventyfive = new HashMap<String,String>();
    HashMap<String,String> seventy = new HashMap<String,String>();
    HashMap<String,String> sixtyfive = new HashMap<String,String>();
    HashMap<String,String> sixty = new HashMap<String,String>();
    HashMap<String,String> fiftyfive = new HashMap<String,String>();

    // full guide for look-up
    // hashmap<integer,<string,string>>
    HashMap<Integer,HashMap<String,String>> paceGuide = new HashMap<Integer,HashMap<String,String>>();

    // constructor
    PaceTable(){
        fill();
        paceGuide.put(95,ninetyfive);
        paceGuide.put(90,ninety);
        paceGuide.put(85,eightyfive);
        paceGuide.put(80,eighty);
        paceGuide.put(75,seventyfive);
        paceGuide.put(70,seventy);
        paceGuide.put(65,sixtyfive);
        paceGuide.put(60,sixty);
        paceGuide.put(55,fiftyfive);
    }

    private void fill() {
        ////// percentages \\\\\\
        // 500 time : goal \\

        ninetyfive.put("2:10","2:16.5");
        ninetyfive.put("2:09","2:15.4");
        ninetyfive.put("2:08","2:14.4");
        ninetyfive.put("2:07","2:13.3");
        ninetyfive.put("2:06","2:12.3");
        ninetyfive.put("2:05","2:11.2");
        ninetyfive.put("2:04","2:10.2");
        ninetyfive.put("2:03","2:09.1");
        ninetyfive.put("2:02","2:08.1");
        ninetyfive.put("2:01","2:07.0");
        ninetyfive.put("2:00","2:06.0");
        ninetyfive.put("1:59","2:04.9");
        ninetyfive.put("1:58","2:03.9");
        ninetyfive.put("1:57","2:02.8");
        ninetyfive.put("1:56","2:01.8");
        ninetyfive.put("1:55","2:00.7");
        ninetyfive.put("1:54","1:59.7");
        ninetyfive.put("1:53","1:58.6");
        ninetyfive.put("1:52","1:57.6");
        ninetyfive.put("1:51","1:56.5");
        ninetyfive.put("1:50","1:55.5");
        ninetyfive.put("1:49","1:54.4");
        ninetyfive.put("1:48","1:53.4");
        ninetyfive.put("1:47","1:52.3");
        ninetyfive.put("1:46","1:51.3");
        ninetyfive.put("1:45","1:50.2");
        ninetyfive.put("1:44","1:49.2");
        ninetyfive.put("1:43","1:48.1");
        ninetyfive.put("1:42","1:47.1");
        ninetyfive.put("1:41","1:46.1");
        ninetyfive.put("1:40","1:45.0");
        ninetyfive.put("1:39","1:43.9");
        ninetyfive.put("1:38","1:42.9");
        ninetyfive.put("1:37","1:41.9");
        ninetyfive.put("1:36","1:40.8");
        ninetyfive.put("1:35","1:39.7");
        ninetyfive.put("1:34","1:38.7");
        ninetyfive.put("1:33","1:37.6");
        ninetyfive.put("1:32","1:36.6");
        ninetyfive.put("1:31","1:35.6");
        ninetyfive.put("1:30","1:34.5");


        ninety.put("2:10","2:23.0");
        ninety.put("2:09","2:21.9");
        ninety.put("2:08","2:20.8");
        ninety.put("2:07","2:19.7");
        ninety.put("2:06","2:18.6");
        ninety.put("2:05","2:17.5");
        ninety.put("2:04","2:16.4");
        ninety.put("2:03","2:15.3");
        ninety.put("2:02","2:14.2");
        ninety.put("2:01","2:13.1");
        ninety.put("2:00","2:12.0");
        ninety.put("1:59","2:10.9");
        ninety.put("1:58","2:09.8");
        ninety.put("1:57","2:08.7");
        ninety.put("1:56","2:07.6");
        ninety.put("1:55","2:06.5");
        ninety.put("1:54","2:05.4");
        ninety.put("1:53","2:04.3");
        ninety.put("1:52","2:03.2");
        ninety.put("1:51","2:02.1");
        ninety.put("1:50","2:01.0");
        ninety.put("1:49","1:59.9");
        ninety.put("1:48","1:58.8");
        ninety.put("1:47","1:57.7");
        ninety.put("1:46","1:56.6");
        ninety.put("1:45","1:55.5");
        ninety.put("1:44","1:54.4");
        ninety.put("1:43","1:53.3");
        ninety.put("1:42","1:52.2");
        ninety.put("1:41","1:51.2");
        ninety.put("1:40","1:50.0");
        ninety.put("1:39","1:48.9");
        ninety.put("1:38","1:47.8");
        ninety.put("1:37","1:46.7");
        ninety.put("1:36","1:45.6");
        ninety.put("1:35","1:44.5");
        ninety.put("1:34","1:43.4");
        ninety.put("1:33","1:42.3");
        ninety.put("1:32","1:41.2");
        ninety.put("1:31","1:40.2");
        ninety.put("1:30","1:39.0");

        eightyfive.put("2:10","2:29.5");
        eightyfive.put("2:09","2:28.3");
        eightyfive.put("2:08","2:27.2");
        eightyfive.put("2:07","2:26.0");
        eightyfive.put("2:06","2:24.9");
        eightyfive.put("2:05","2:23.7");
        eightyfive.put("2:04","2:22.6");
        eightyfive.put("2:03","2:21.4");
        eightyfive.put("2:02","2:20.3");
        eightyfive.put("2:01","2:19.1");
        eightyfive.put("2:00","2:18.0");
        eightyfive.put("1:59","2:16.8");
        eightyfive.put("1:58","2:15.7");
        eightyfive.put("1:57","2:14.5");
        eightyfive.put("1:56","2:13.4");
        eightyfive.put("1:55","2:12.2");
        eightyfive.put("1:54","2:11.1");
        eightyfive.put("1:53","2:09.9");
        eightyfive.put("1:52","2:08.8");
        eightyfive.put("1:51","2:07.6");
        eightyfive.put("1:50","2:06.5");
        eightyfive.put("1:49","2:05.3");
        eightyfive.put("1:48","2:04.2");
        eightyfive.put("1:47","2:03.0");
        eightyfive.put("1:46","2:01.9");
        eightyfive.put("1:45","2:00.7");
        eightyfive.put("1:44","1:59.6");
        eightyfive.put("1:43","1:58.4");
        eightyfive.put("1:42","1:57.3");
        eightyfive.put("1:41","1:56.2");
        eightyfive.put("1:40","1:55.0");
        eightyfive.put("1:39","1:53.8");
        eightyfive.put("1:38","1:52.7");
        eightyfive.put("1:37","1:51.5");
        eightyfive.put("1:36","1:50.4");
        eightyfive.put("1:35","1:49.2");
        eightyfive.put("1:34","1:48.1");
        eightyfive.put("1:33","1:46.9");
        eightyfive.put("1:32","1:45.8");
        eightyfive.put("1:31","1:44.7");
        eightyfive.put("1:30","1:43.5");

        eighty.put("2:10","2:36.0");
        eighty.put("2:09","2:34.8");
        eighty.put("2:08","2:33.6");
        eighty.put("2:07","2:32.4");
        eighty.put("2:06","2:31.2");
        eighty.put("2:05","2:30.0");
        eighty.put("2:04","2:28.8");
        eighty.put("2:03","2:27.6");
        eighty.put("2:02","2:26.4");
        eighty.put("2:01","2:25.2");
        eighty.put("2:00","2:24.0");
        eighty.put("1:59","2:22.8");
        eighty.put("1:58","2:21.6");
        eighty.put("1:57","2:20.4");
        eighty.put("1:56","2:19.2");
        eighty.put("1:55","2:18.0");
        eighty.put("1:54","2:16.8");
        eighty.put("1:53","2:15.6");
        eighty.put("1:52","2:14.4");
        eighty.put("1:51","2:13.2");
        eighty.put("1:50","2:12.0");
        eighty.put("1:49","2:10.0");
        eighty.put("1:48","2:09.6");
        eighty.put("1:47","2:08.4");
        eighty.put("1:46","2:07.2");
        eighty.put("1:45","2:05.9");
        eighty.put("1:44","2:04.8");
        eighty.put("1:43","2:03.6");
        eighty.put("1:42","2:02.4");
        eighty.put("1:41","2:01.3");
        eighty.put("1:40","2:00.0");
        eighty.put("1:39","1:58.8");
        eighty.put("1:38","1:57.6");
        eighty.put("1:37","1:56.4");
        eighty.put("1:36","1:55.2");
        eighty.put("1:35","1:54.0");
        eighty.put("1:34","1:52.8");
        eighty.put("1:33","1:51.6");
        eighty.put("1:32","1:50.4");
        eighty.put("1:31","1:49.3");
        eighty.put("1:30","1:48.0");


        seventyfive.put("2:10","2:42.5");
        seventyfive.put("2:09","2:41.2");
        seventyfive.put("2:08","2:40.0");
        seventyfive.put("2:07","2:38.7");
        seventyfive.put("2:06","2:37.5");
        seventyfive.put("2:05","2:36.2");
        seventyfive.put("2:04","2:35.0");
        seventyfive.put("2:03","2:33.7");
        seventyfive.put("2:02","2:32.5");
        seventyfive.put("2:01","2:31.2");
        seventyfive.put("2:00","2:30.0");
        seventyfive.put("1:59","2:28.7");
        seventyfive.put("1:58","2:27.5");
        seventyfive.put("1:57","2:26.2");
        seventyfive.put("1:56","2:25.0");
        seventyfive.put("1:55","2:23.3");
        seventyfive.put("1:54","2:22.5");
        seventyfive.put("1:53","2:21.2");
        seventyfive.put("1:52","2:20.0");
        seventyfive.put("1:51","2:18.7");
        seventyfive.put("1:50","2:17.5");
        seventyfive.put("1:49","2:16.2");
        seventyfive.put("1:48","2:15.0");
        seventyfive.put("1:47","2:13.7");
        seventyfive.put("1:46","2:12.5");
        seventyfive.put("1:45","2:11.2");
        seventyfive.put("1:44","2:10.0");
        seventyfive.put("1:43","2:08.7");
        seventyfive.put("1:42","2:07.5");
        seventyfive.put("1:41","2:06.3");
        seventyfive.put("1:40","2:05.0");
        seventyfive.put("1:39","2:03.7");
        seventyfive.put("1:38","2:02.5");
        seventyfive.put("1:37","2:01.2");
        seventyfive.put("1:36","2:00.0");
        seventyfive.put("1:35","1:58.7");
        seventyfive.put("1:34","1:57.5");
        seventyfive.put("1:33","1:56.3");
        seventyfive.put("1:32","1:55.0");
        seventyfive.put("1:31","1:53.9");
        seventyfive.put("1:30","1:52.5");


        seventy.put("2:10","2:49.0");
        seventy.put("2:09","2:47.7");
        seventy.put("2:08","2:46.4");
        seventy.put("2:07","2:45.1");
        seventy.put("2:06","2:43.8");
        seventy.put("2:05","2:42.5");
        seventy.put("2:04","2:41.2");
        seventy.put("2:03","2:39.9");
        seventy.put("2:02","2:38.6");
        seventy.put("2:01","2:37.3");
        seventy.put("2:00","2:36.0");
        seventy.put("1:59","2:34.7");
        seventy.put("1:58","2:33.4");
        seventy.put("1:57","2:32.1");
        seventy.put("1:56","2:30.8");
        seventy.put("1:55","2:29.5");
        seventy.put("1:54","2:28.2");
        seventy.put("1:53","2:26.9");
        seventy.put("1:52","2:25.6");
        seventy.put("1:51","2:24.3");
        seventy.put("1:50","2:23.0");
        seventy.put("1:49","2:21.7");
        seventy.put("1:48","2:20.4");
        seventy.put("1:47","2:19.1");
        seventy.put("1:46","2:17.8");
        seventy.put("1:45","2:16.4");
        seventy.put("1:44","2:15.2");
        seventy.put("1:43","2:13.9");
        seventy.put("1:42","2:12.6");
        seventy.put("1:41","2:11.4");
        seventy.put("1:40","2:10.0");
        seventy.put("1:39","2:08.7");
        seventy.put("1:38","2:07.4");
        seventy.put("1:37","2:06.1");
        seventy.put("1:36","2:04.8");
        seventy.put("1:35","2:03.5");
        seventy.put("1:34","2:02.2");
        seventy.put("1:33","2:00.9");
        seventy.put("1:32","1:59.6");
        seventy.put("1:31","1:58.4");
        seventy.put("1:30","1:57.0");


        sixtyfive.put("2:10","2:55.5");
        sixtyfive.put("2:09","2:54.1");
        sixtyfive.put("2:08","2:52.8");
        sixtyfive.put("2:07","2:51.4");
        sixtyfive.put("2:06","2:50.1");
        sixtyfive.put("2:05","2:48.7");
        sixtyfive.put("2:04","2:47.4");
        sixtyfive.put("2:03","2:46.0");
        sixtyfive.put("2:02","2:44.7");
        sixtyfive.put("2:01","2:43.3");
        sixtyfive.put("2:00","2:42.0");
        sixtyfive.put("1:59","2:40.6");
        sixtyfive.put("1:58","2:39.3");
        sixtyfive.put("1:57","2:37.9");
        sixtyfive.put("1:56","2:36.6");
        sixtyfive.put("1:55","2:35.2");
        sixtyfive.put("1:54","2:33.9");
        sixtyfive.put("1:53","2:32.5");
        sixtyfive.put("1:52","2:31.2");
        sixtyfive.put("1:51","2:29.8");
        sixtyfive.put("1:50","2:28.5");
        sixtyfive.put("1:49","2:27.1");
        sixtyfive.put("1:48","2:25.8");
        sixtyfive.put("1:47","2:24.4");
        sixtyfive.put("1:46","2:23.1");
        sixtyfive.put("1:45","2:21.7");
        sixtyfive.put("1:44","2:20.4");
        sixtyfive.put("1:43","2:19.0");
        sixtyfive.put("1:42","2:17.7");
        sixtyfive.put("1:41","2:16.4");
        sixtyfive.put("1:40","2:15.0");
        sixtyfive.put("1:39","2:13.6");
        sixtyfive.put("1:38","2:12.3");
        sixtyfive.put("1:37","2:10.9");
        sixtyfive.put("1:36","2:09.6");
        sixtyfive.put("1:35","2:08.2");
        sixtyfive.put("1:34","2:06.9");
        sixtyfive.put("1:33","2:05.5");
        sixtyfive.put("1:32","2:04.2");
        sixtyfive.put("1:31","2:02.9");
        sixtyfive.put("1:30","2:01.5");

        sixty.put("2:10","3:02.0");
        sixty.put("2:09","3:00.6");
        sixty.put("2:08","2:59.2");
        sixty.put("2:07","2:57.8");
        sixty.put("2:06","2:56.4");
        sixty.put("2:05","2:55.0");
        sixty.put("2:04","2:53.6");
        sixty.put("2:03","2:52.2");
        sixty.put("2:02","2:50.8");
        sixty.put("2:01","2:49.4");
        sixty.put("2:00","2:48.0");
        sixty.put("1:59","2:46.6");
        sixty.put("1:58","2:45.2");
        sixty.put("1:57","2:43.8");
        sixty.put("1:56","2:42.4");
        sixty.put("1:55","2:41.0");
        sixty.put("1:54","2:39.6");
        sixty.put("1:53","2:38.2");
        sixty.put("1:52","2:36.8");
        sixty.put("1:51","2:35.4");
        sixty.put("1:50","2:34.0");
        sixty.put("1:49","2:32.6");
        sixty.put("1:48","2:31.2");
        sixty.put("1:47","2:29.8");
        sixty.put("1:46","2:28.4");
        sixty.put("1:45","2:26.7");
        sixty.put("1:44","2:25.6");
        sixty.put("1:43","2:24.2");
        sixty.put("1:42","2:22.8");
        sixty.put("1:41","2:21.5");
        sixty.put("1:40","2:20.0");
        sixty.put("1:39","2:18.6");
        sixty.put("1:38","2:17.2");
        sixty.put("1:37","2:15.8");
        sixty.put("1:36","2:14.4");
        sixty.put("1:35","2:13.0");
        sixty.put("1:34","2:11.6");
        sixty.put("1:33","2:10.2");
        sixty.put("1:32","2:08.8");
        sixty.put("1:31","2:07.5");
        sixty.put("1:30","2:06.0");


        fiftyfive.put("2:10","3:08.5");
        fiftyfive.put("2:09","3:07.0");
        fiftyfive.put("2:08","3:05.6");
        fiftyfive.put("2:07","3:04.1");
        fiftyfive.put("2:06","3:02.7");
        fiftyfive.put("2:05","3:01.2");
        fiftyfive.put("2:04","2:59.8");
        fiftyfive.put("2:03","2:58.3");
        fiftyfive.put("2:02","2:56.9");
        fiftyfive.put("2:01","2:55.4");
        fiftyfive.put("2:00","2:54.0");
        fiftyfive.put("1:59","2:52.5");
        fiftyfive.put("1:58","2:51.1");
        fiftyfive.put("1:57","2:49.6");
        fiftyfive.put("1:56","2:48.2");
        fiftyfive.put("1:55","2:46.7");
        fiftyfive.put("1:54","2:45.3");
        fiftyfive.put("1:53","2:43.8");
        fiftyfive.put("1:52","2:52.4");
        fiftyfive.put("1:51","2:40.9");
        fiftyfive.put("1:50","2:39.5");
        fiftyfive.put("1:49","2:38.0");
        fiftyfive.put("1:48","2:36.6");
        fiftyfive.put("1:47","2:35.1");
        fiftyfive.put("1:46","2:33.7");
        fiftyfive.put("1:45","2:31.9");
        fiftyfive.put("1:44","2:30.8");
        fiftyfive.put("1:43","2:29.3");
        fiftyfive.put("1:42","2:27.9");
        fiftyfive.put("1:41","2:26.5");
        fiftyfive.put("1:40","2:25.0");
        fiftyfive.put("1:39","2:23.5");
        fiftyfive.put("1:38","2:22.1");
        fiftyfive.put("1:37","2:20.6");
        fiftyfive.put("1:36","2:19.2");
        fiftyfive.put("1:35","2:17.7");
        fiftyfive.put("1:34","2:16.3");
        fiftyfive.put("1:33","2:14.9");
        fiftyfive.put("1:32","2:13.4");
        fiftyfive.put("1:31","2:12.0");
        fiftyfive.put("1:30","2:10.5");
    }

    // pace finder
    public String pace(Integer min, Integer max, String test){
        ArrayList<String> goals = new ArrayList<String>();
        HashMap<String,String> time;
        String t;
        while(min<max){
            time = paceGuide.get(min);
            t = time.get(test);
            goals.add(min + "%: " + t);
            min+=5;
        }
        //in case the percentages were entered from higher to lower value
        while(min>=max){
            time = paceGuide.get(max);
            t = time.get(test);
            goals.add(max + "%: " + t);
            max+=5;
        }
        String report = "";
        //writes the goal splits to a string
        for(String s : goals){
            report += s + "\n";
        }
        return(report);
    }
}
