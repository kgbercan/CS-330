package edu.simmons.bercan.paceguide;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class Main extends AppCompatActivity {

    //initialize pace guide
    PaceTable pt = new PaceTable();
    //set default values
    String ergScore = "1:47";
    Integer lowPct = 80;
    Integer highPct = 90;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //create array of pcts
        Integer pct[] = {55,60,65,70,75,80,85,90,95};
        //initialize spinners and values
        Spinner lowPctText = (Spinner) findViewById(R.id.lowPctSpinner);
        ArrayAdapter<Integer> pctAdapter = new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_dropdown_item,pct);
        pctAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lowPctText.setAdapter(pctAdapter);

        Spinner highPctText = (Spinner) findViewById(R.id.highPctSpinner);
        highPctText.setAdapter(pctAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void report(View view){
        //set 500m time
        EditText ergScoreText = (EditText) findViewById(R.id.ergScoreTextField);
        ergScore = ergScoreText.getText().toString();

        //set percentage
        Spinner lowPctText = (Spinner) findViewById(R.id.lowPctSpinner);
        lowPct = (Integer) lowPctText.getSelectedItem();

        //set percentage
        Spinner highPctText = (Spinner) findViewById(R.id.highPctSpinner);
        highPct = (Integer) highPctText.getSelectedItem();

        EditText goalLabel = (EditText) findViewById(R.id.goalLabel);
        //log variables to make sure it worked :)
        System.out.println(ergScore);
        System.out.println(lowPct + "%-" + highPct + "%");
        System.out.println(pt.pace(lowPct, highPct, ergScore));
        //display results
        goalLabel.setText(pt.pace(lowPct, highPct, ergScore));
    }

}
